字由（hellofont）使用教程

方法1：
1.打开设计软件（如PS、AI）
2.新建文档，输入文字内容
3.打开字由，在客户端选择想要的字体，点击激活（呼吸灯变绿表示激活成功）
4.点击字体图层，再点激活过的字体
5.字体变化，应用成功

方法2：
1.在客户端点击激活想要使用的字体
2.打开设计软件（如PS、AI），在字体列表里选择相应字体并应用

Windows客户端下载：https://www.fontke.com/download/HelloFont.zip
Mac OS客户端下载：https://www.fontke.com/download/HelloFont.dmg

目前支持字由客户端的软件：
Photoshop，Illustrator，Indesign（暂支持Mac OS客户端），Coreldraw，Sketch，Word（仅支持Microsoft Office），PowerPoint（仅支持Microsoft Office），Keynote

字由官网：http://www.hellofont.cn/

字由微信公众号：字由（hellofont）
